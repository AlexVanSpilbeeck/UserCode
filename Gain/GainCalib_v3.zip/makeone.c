#include <fstream>
#include <string>
#include <iostream>
#include <sys/stat.h> 

void makeone(){
  
  ifstream in;
  ofstream out;
  
  ofstream hadd1;
  ofstream hadd2;
  char* file = "STOREdir/%d.root ";
  char tmp[120];
  hadd1.open("../Hadd1.txt");
  hadd2.open("../Hadd2.txt");
  
  out.open("Summary.txt");
  char name[120];
  struct stat Stat;
  int TotalNbOfPixel = 0;
  int status[9]={0,0,0,0,0,0,0,0,0};
  for(int i=1;i<41;i++)
  {
    strcpy(name,"Summary_%d.txt");
    sprintf(name,name,i);
    if(stat(name,&Stat)) {std::cout<<"File "<<i<<" from FED "<<i-1<<" was not computed"<<std::endl;continue;}
    
    in.open(name);
    if(in.is_open())
    {
      string c1;
      getline(in,c1);
      if(c1=="") {std::cout<<"Problem processing file "<<name<<endl;continue;}
      
      std::cout<<"Computing file "<<name<<" ..."<<std::endl;
      c1.erase(c1.begin(),c1.begin()+32);
      TotalNbOfPixel+=atoi(c1.c_str());
      getline(in,c1);
      
      for(int j=0;j<9;j++)
      {
        getline(in,c1);
	c1.erase(c1.begin(),c1.begin()+5);
	c1.erase(c1.begin()+c1.find_first_of(" "),c1.end());
	status[j]+=atoi(c1.c_str());
      }
      in.close();
      
      //Make Hadd list from valid files
      sprintf(tmp,file,i);
      if(i<21) hadd1 <<tmp;
      else hadd2 <<tmp;
    }
  }
  
  out<<"Total Number of Pixel computed :"<<TotalNbOfPixel<<endl;
  out<<"Number of pixel tagged with status :"<<endl;
  for(int ii=0;ii<9;ii++)
    out<<ii<<" -> "<<status[ii]<<" ~ "<<double(status[ii])/double(TotalNbOfPixel)*100.<<" %"<<endl;
}
