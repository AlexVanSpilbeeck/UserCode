import FWCore.ParameterSet.Config as cms

process = cms.Process("SLINKTORAW")

process.maxEvents = cms.untracked.PSet(
    input = cms.untracked.int32(-1)
)

process.load("FWCore.MessageService.MessageLogger_cfi")
process.MessageLogger.cerr.FwkReport.reportEvery = 10000

process.source= cms.Source("PixelSLinkDataInputSource",
                                               runNumber = cms.untracked.int32(-1),
                                               fileNames = cms.untracked.vstring("rfio:///INPUTFILE"),
                                               fedid = cms.untracked.int32(-1)
                                               )

process.o1 = cms.OutputModule("PoolOutputModule",
                              fileName=cms.untracked.string("rfio:///OUTPUTFILE")
                              )

process.outpath = cms.EndPath(process.o1)
