#!/bin/csh

########################
##
##   Script to run the gain calibration on all 40 FEDs
##
##
##   HowTo : source Run_GainCalibration.sh RUNNUMBER INPUTDIR STOREDIR
##
##
##
########################

#################
# Set the extension for input root files
set ext=dmp

setenv runningdir Run_$1
setenv storedir $3


if (! -d ${runningdir} ) then
  mkdir ${runningdir}
else
  rm -r ${runningdir}/*
endif 

if ( -e filelist.txt ) then
  rm filelist.txt
endif

if ( -e client_template_calib_cfg.py ) then
  rm client_template_calib_cfg.py
endif

if ( -e es.log ) then
  rm es.log
endif

#sed "s/RUNNUMBER/$1/" < filelist_template.txt > filelist.txt
echo -n > filelist.txt
foreach file (`nsls $2 |grep "$1.${ext}"`)
  echo "$2/$file">>filelist.txt
end

switch ( ${ext} )
  case "dmp":
    echo "Using dmp files !"
    #sed "s#SOURCE#PixelSLinkDataInputSource#" < gaincalib_template_cfg.py > client_template_calib_cfg.py
    breaksw
  case "root":
    echo "Using root files !"
    #sed "s#SOURCE#PoolSource#" < gaincalib_template_cfg.py > client_template_calib_cfg.py
    breaksw
  default:
    echo "Files must be dmp or root !"
    breaksw
endsw
cp gaincalib_template_cfg.py client_template_calib_cfg.py

source Run_offline_DQM.csh filelist.txt Calibration
mv Run_offline_DQM_* filelist.txt ${runningdir}/.

sed "s#STOREdir#${storedir}/GainRun_$1#" < Hadd_template.csh > TEMP0_Hadd_template.csh
sed "s#RUNNINGDIR#`pwd`/${runningdir}#" < TEMP0_Hadd_template.csh > ${runningdir}/Hadd.csh
rm TEMP0_Hadd_template.csh

sed "s#RUNNUMBER#$1#" < submit_hadd.csh > TEMP0_submit_hadd.csh
sed "s#STOREdir#${storedir}/GainRun_$1#" < TEMP0_submit_hadd.csh > ${runningdir}/submit_hadd.csh
rm TEMP0_submit_hadd.csh

sed "s#STOREdir#${storedir}/GainRun_$1#" < submit.csh > ${runningdir}/submit.csh
sed "s#STOREdir#${storedir}/GainRun_$1#" < makeone.c > ${runningdir}/makeone.c

mkdir ${runningdir}/Summary_Run$1
cp -fr scripts/make_SummaryPlots.cc ${runningdir}/Summary_Run$1/make_SummaryPlots_template.cc
cp -fr scripts/gain_summary.txt  ${runningdir}/Summary_Run$1/gain_summary_template.tex
cp -fr scripts/TMean.* ${runningdir}/Summary_Run$1/.
sed "s#STOREdir#${storedir}/GainRun_$1#" < scripts/submit_summary.csh > TEMP0_submit_summary.csh
sed "s#RUNNINGDIR#`pwd`/${runningdir}/Summary_Run$1/#" < TEMP0_submit_summary.csh > TEMP1_submit_summary.csh
sed "s#RUNnumber#$1#" < TEMP1_submit_summary.csh > ${runningdir}/submit_summary.csh
rm -fr TEMP0_submit_summary.csh TEMP1_submit_summary.csh

cp  submit_template.csh ${runningdir}/.
cd ${runningdir}

source submit.csh $1

rm submit_template.csh 
mv makeone.c TEXToutput/
