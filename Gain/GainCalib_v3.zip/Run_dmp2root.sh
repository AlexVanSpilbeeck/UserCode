#!/bin/csh
##
##   Script to convert dmp files to root
##   Created by Romain Rougny
## 
##
##   HowTo : source Run_dmp2root.sh INPUTDIR RUNNUMBER OUTPUTDIR
##
##

setenv workingdir RAW_Run_$2
if (! -d ${workingdir} ) then
  mkdir ${workingdir}
else
  rm -r ${workingdir}/*
endif

cp slinktoraw_template_cfg.py submit_dmp2root_template.csh ${workingdir}/
cd ${workingdir}

set i=0
foreach file (`nsls $1 |grep "$2.dmp"`)
  sed "s#OUTPUTFILE#$3/$file#" < slinktoraw_template_cfg.py > temp1
  sed "s#.dmp#.root#" < temp1 > temp2
  sed "s#INPUTFILE#$1/$file#" < temp2 > slinktoraw_${i}_cfg.py
  
  sed "s#PwD#`pwd`#" < submit_dmp2root_template.csh > temp3
  sed "s#CFG#slinktoraw_${i}_cfg.py#" < temp3 > submit_dmp2root_${i}.csh
  
  echo "Submitting file $file :"
  bsub -q 1nh -J dmp2root_$2_$i < submit_dmp2root_${i}.csh
 # cmsRun slinktoraw_${i}_cfg.py
  
  rm temp1 temp2 temp3
  @ i = $i + 1
end

